# I‑9 — независимая сверка GitHub CI

Дата сверки 24 ноября 2026 г. Кандидат `72dad18c11feb8d9d8b62b702b05f54ed7ffad1d`, ветка `fix/i9-acceptance`. Принятая интеграция `a86a9680f88aa89e9d661095a30564f50afe23ba`. По сравнению GitHub изменен только `DESIGN_SYSTEM.md`. [Сравнение](https://github.com/IskhakovMA/fixes/compare/a86a9680f88aa89e9d661095a30564f50afe23ba...72dad18c11feb8d9d8b62b702b05f54ed7ffad1d)

**CI BLOCKED.** Исходный workflow `45393820543`, попытка 1, завершился со статусом `failure`. История на SHA кандидата при сверке содержала только эту попытку. Все **13 из 15 jobs** действительно выполнялись. Для каждой проверены назначение раннера, завершение всех шагов и доступный журнал. [Run](https://github.com/IskhakovMA/fixes/actions/runs/45393820543)

| Проверка | Результат | Журнал |
|---|---|---|
| backend-test-plan | PASS. 2821 тест, 121 файл. Собранный план проверен на полноту и детерминизм. | [138444437246](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437246) |
| dependency-audit | PASS. Pip-audit не обнаружил известных уязвимостей. | [138444437664](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437664) |
| backend-smoke | PASS. Временная DB, проверка целостности и компиляция backend. | [138444437729](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437729) |
| sast-bandit | PASS. Самопроверка gate и Bandit. 19 проверенных allowlist-находок, 0 неожиданных, 0 устаревших, 0 ошибок анализа. | [138444437768](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437768) |
| workflow-policy | PASS. 53 теста. | [138444437883](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437883) |
| secret-scan | PASS. Положительный контроль и отрицательные сканы рабочего дерева, истории и изменений внутри merge-коммитов. | [138444437954](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444437954) |
| frontend-security | PASS. JavaScript syntax, 81 Staff‑UX тест, 35 frontend security тестов. | [138444438128](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444438128) |
| shard 1 | PASS. 471 exact-once. | [138444689980](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444689980) |
| shard 2 | PASS. 470 exact-once. | [138444689961](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444689961) |
| shard 3 | PASS. 470 exact-once. | [138444690074](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444690074) |
| shard 4 | PASS. 470 exact-once. | [138444689952](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444689952) |
| shard 5 | PASS. 470 exact-once. | [138444690031](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444690031) |
| shard 6 | PASS. 470 exact-once. | [138444689990](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138444689990) |
| backend-tests-verify | BLOCKED. GitHub `failure`, раннер отсутствует, 0 шагов, лог отсутствует. | [138454121208](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138454121208) |
| release-gate | BLOCKED. GitHub `failure`, раннер отсутствует, 0 шагов, лог отсутствует. Аннотация GitHub указывает на ограничение оплаты или лимита расходов. | [138454141069](https://github.com/IskhakovMA/fixes/actions/runs/45393820543/job/138454141069) |

SHA‑256 плана `6f867465e8e8dcc9e801283827498bddf4480f183f921a5b92d1189b45f1b720`. Каждый шард пересобирал план с ожидаемыми count и digest и завершил `verify-shard`, поэтому журналы совместно подтверждают прохождение **2821/2821 exact-once**. Сам итоговый `backend-tests-verify` в этой попытке не исполнялся. Workflow не передает отдельный artifact с outcomes в fan-in. Outcomes проверяются внутри каждого шарда. Fan-in требует успешных плана и всей матрицы и выводит count плана. После разблокировки повтор failed jobs допустим только на том же SHA. Для признания PASS нужны фактический fan-in с `plan: success; shards: success; collected tests: 2821`, успешный release-gate по всем девяти зависимостям, и итог `success` на SHA кандидата. [Точный workflow](https://github.com/IskhakovMA/fixes/blob/72dad18c11feb8d9d8b62b702b05f54ed7ffad1d/.github/workflows/ci.yml#L98-L156)

Сохранены только выбранные агрегированные результаты. Полные журналы и содержимое тестовых баз в пакет не включены.

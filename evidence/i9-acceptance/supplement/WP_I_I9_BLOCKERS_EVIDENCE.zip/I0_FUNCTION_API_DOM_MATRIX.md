# I-0 — матрица сохранения функций и связей

База05ba90df; утвержденные D1–D8 применены. Полный API-каталог: route-inventory.json (127 маршрутов). Полный ID/handler-каталог: dom-baseline.json. Матрица ниже объединяет их с регрессиями; не утверждает ручную проверку каждого редкого сценария. Фактические результаты — в итоговом отчете и логах.

| Функция | DOM / элементы | API | Зависимости и проверки |
|---|---|---|---|
| Вход/выход/временный пароль | loginScreen, loginForm, username, password, forcePasswordForm, logoutBtn | /api/auth/login,logout,me,change-password,activity | bindStaticControls → login/logout/resumeSession; WP-D/G browser; shell role login/logout/reauth |
| Оболочка и темы | appScreen, sidebar, sidebarToggle, sidebarScrim, themeToggle, themeSelect | API не добавляется; прежний /api/auth/me определяет permissions | applyRoleUI/showView/syncSidebarFocus/applyTheme; shell6roles; keyboard320/375; native zoom |
| Пациенты: поиск/фильтры/пагинация | view-patients, searchInput, filterStage, filterHead, filterDeadline, filterAttention, filterAttentionReason, sortOrderSelect, patientsBody | GET /api/patients?view=page; resolve; head-options | WP-H browser/drafts; backend test_wp_h_pages + test_wp_h_fix1_release; no legacy downloads |
| Карточка и8вкладок | view-patient, patientTabs, patientPanels; динамические tab-* | GET /api/patients/{id}; прежние field/event/history/stage mutation API | WP-D FIX2; WP-H drafts; keyboard Home/End/arrows; все версии и original drafts сохраняются |
| Консилиум | view-consilium и все исходные consilium* IDs | /api/consilium/*; /api/patients/workspace/patients | nav6roles; исходные test_wp22*,test_wp23*; права подписи/архива/реестров не меняются |
| Календарь | view-calendar, calendarPanel | GET /api/patients/workspace/events | nav6roles; WP-H page/release tests; API/фильтры не расширяются |
| Чек-листы | view-checklists, checklistsPanel | GET /api/patients/workspace/checklists; PATCH history checklist | nav6roles; test_wp_h_pages/release; обязательные/завершенные не теряются |
| Внутренние уведомления | view-notifications, internalNotificationsBell, internalNotificationsDrawer, notificationsInboxPanel | /api/internal-notifications/* | nav6roles; WP-E inbox/notification tests; прежние mark/read/all handlers |
| Уведомления пациенту/шаблоны | notificationsOutboundPanel, notificationTemplatesPanel; patient notifications tab | /api/notifications/*; /api/notification-templates | WP-E browser; backend time/queue/templates; mock/consent/UTC без изменений |
| Аналитика | view-analytics, analyticsStatsRow, analyticsDetailsPanel | /api/analytics/* | nav6roles; существующие backend analytics и WP-H detail pager assertions |
| Качество данных | view-quality, qualityToolbarFilters, qualityDuplicatesPanel | /api/data-quality/* | nav6roles; существующие backend data-quality; полная серверная выборка |
| Дубли/ошибочные карточки | view-duplicates; исходные duplicates* controls | /api/duplicates/* | developer/deputy видимость, CAOP скрыто; test_wp24d_duplicate_review |
| Импорт/экспорт/старый перенос | view-data, migrationPanel; все import*/export* IDs | /api/import/*; /api/export; /api/export/selection; /api/migrate/localstorage/* | nav6roles; WP-F FIX2 browser; idempotency/manifest/signature backend tests |
| Сотрудники | view-staff; исходные staff* IDs | /api/users/* | developer-only nav; WP-D FIX1 revoke/multi-tab; user/session backend tests |
| Структура/сопоставление | view-structure, structurePanel, unresolvedPanel | /api/departments/*; /api/patients/unresolved; treating-doctor | developer-only nav; WP-D FIX1 department changes; test_policy/integration |
| Аудит/manifest | view-audit, auditPanel | /api/audit; /api/audit/{event_id}/manifest | developer-only nav; WP-G manifest/failure/atomicity backend tests |
| Настройки | view-settings, themeSelect; прежняя форма пароля | /api/auth/change-password; тема локально | nav6roles; both themes; password/idle/MFA backend regressions |
| ИИ drawer | aiAssistantBtn, aiAssistantDrawer, aiAssistantForm, aiAssistantClose | /api/ai/status; POST /api/ai/chat | WP-D stale/identity; backend AI allowlist/DTO; S1/провайдеры не меняются |
| Создание пациента | openAddBtn, addModal, addForm, submitAddBtn | POST /api/patients + Idempotency-Key | keyboard trap/Escape/return-focus; WP-D draft/reauth; WP24A/B/C; остается modal, неI-4 |
| Клинические диалоги/подтверждения | promptModal, confirmModal и все552 исходных IDs | прежние операции с версиями, без новых API | WP-D FIX2 clinical date; modals focus; original ReturnFocus targets/handler binding |
| Portal access | динамический блок в patientPanels; исходные handlers | GET/PUT/DELETE /api/patients/{id}/portal-access | backend integration portal regressions; UI logic/app.js побайтно неизменны |

## Восстановление авторизованного workspace

`pristineWorkspace` создается после parsing HTML из всех body nodes кроме scripts; новый каркас попадает в него целиком. `rebuildAuthorizedWorkspace()` сохраняет разрешенные drafts/создание/prompt, abort старых globalControls, очищает ui.openModals/returnFocusTargets, заменяет body свежими клонами, вызывает bindStaticControls/applyRoleUI и восстанавливает разрешенные данные. Все эти функции в неизмененном app.js.

Все552 исходных DOM ID сохранены; добавлены только workspaceMain и три ID заголовков групп; дублей нет. Nav-кнопки остаются .nav__item[data-view], поэтому существующий querySelectorAll связывает каждую один раз. Порядок duplicates изменен только для группы «Контроль». Ни одного нового on-handler/inline style/innerHTML.

`ui.openModal/closeModal/trapFocus`, returnFocusTargets и dataset.returnFocus остаются на прежних кнопках. Вложенные SVG aria-hidden/focusable=false не меняют доступные названия. Sidebar inert/aria-hidden/MutationObserver/resize/Escape прежние; CSS не отменяет hidden/is-hidden/inert. Группы скрываются по фактической видимости прежних кнопок и не добавляют роль/permission.

Проверка rebuild: полноценная повторная авторизация того же сотрудника,13 кнопок и3 группы после пересоздания, ровно одно переключение темы; WP-D FIX1/FIX2 отдельно проверяют смену личности/прав/открытые drafts и клинический prompt.

## Восемь вкладок

| Ключ | Название | Источник/операция |
|---|---|---|
| overview | Обзор | detail + attention/quality/portal; medical read audit |
| notifications | Уведомления | patient preferences/templates/history; mock only |
| data | Данные | field PATCH + expectedVersion; независимое сохранение |
| complaints | Комментарии | complaint field + original draft version |
| events | События и даты | event ID/version, stage/manual decision раздельно |
| checklist | Чек-лист | history occurrence checklist PATCH |
| notes | Заметки | history occurrence note PATCH |
| history | История | server history/diagnosisHistory; чтение |

Отрисовка вкладок и medical event delegation не меняются. Список2534 baseline ID сохранен отдельно; итоговый full-run обязан иметь тот же digest и точное множество.

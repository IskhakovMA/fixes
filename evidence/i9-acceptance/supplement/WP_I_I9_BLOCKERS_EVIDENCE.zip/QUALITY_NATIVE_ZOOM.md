# I-9 · Quality native zoom

Кандидат: `72dad18c11feb8d9d8b62b702b05f54ed7ffad1d`. Интеграция: `a86a9680f88aa89e9d661095a30564f50afe23ba`. Приватный репозиторий и продуктовый код не менялись.

| Статус | Проверка | Что установлено |
|---|---|---|
| FAIL | Исторический запуск Chrome for Testing 151.0.7922.34, Ubuntu 24.04.5, Python 3.13.18, Node 22.23.5 | Job 138445065148 на точном кандидате завершил подслучай `quality-browser_zoom` с кодом 1. Четыре предыдущих подслучая этого job прошли. |
| BLOCKED | Восстановление полного исходного `browser.local.log` | API вернул декодированный job log и пустой список артефактов. Между строкой FAIL и завершением команды нет вывода Chromium/FastAPI. Отдельный файл из эфемерного runner не опубликован. Историческую первопричину установить по сохранившемуся логу нельзя. |
| PASS | Независимая проверка публикации диагностики в harness | Исходный фильтр не пропускает обычную строку ошибки Playwright при запуске браузера, строку Chromium FATAL и сообщение о SIGTRAP. Прототип фильтра пропускает все эти классы, сохраняя проверки утверждений. Входы прототипа иллюстративные и не являются историческим stderr. |
| BLOCKED | Точный кандидат и отдельно его вариант с тестовым patch, короткий временный каталог, Darwin arm64 | `socket.bind(('127.0.0.1', 0))` завершился EPERM до запуска синтетического FastAPI и Chromium. Chrome 151.0.7922.34, Python 3.13.4, Node 22.23.4. |
| NOT TESTED | Нативные 100/200/400% × светлая/темная, все 50 именованных действий, контент и фокус | Подготовлен тестовый patch. Синтаксис JavaScript и `git apply --check` прошли. Реальный повторный браузерный результат отсутствует. Автоматический axe в patch не заменяет ручной screen reader. |

[Исходный job](https://github.com/IskhakovMA/fixes/actions/runs/45394069815/job/138445065148) · [SHA workflow](https://github.com/IskhakovMA/fixes/blob/8bc652837e5f3285213c7bab5888b61d3e8a7c7b/.github/workflows/i9-isolated-verification.yml)

## Проверяемый риск пути

Исходный `run_browser.py` создает `private-fixture-…` под `--out` и передает его как `TMPDIR` Node и Chromium. На Linux Chromium создает каталог под временным путем для ProcessSingleton и отвергает pathname, который не укладывается в `sockaddr_un.sun_path`. Модель по путям зарегистрированного runner дает 122–134 байта исходного pathname в зависимости от branding prefix, тогда как поле в Linux вмещает 108 байт с завершающим NUL. Предлагаемый короткий путь дает 85–97 байт. Это объясняет технический риск конкретного harness, но не подтверждает, что именно он вызвал исторический код 1. Для этого нужен оригинальный stderr или воспроизведение на допущенном Linux runner.

[Chromium ProcessSingleton](https://chromium.googlesource.com/chromium/src/+/refs/heads/main/chrome/browser/process_singleton_posix.cc#1046) · [Chromium POSIX temporary directory](https://chromium.googlesource.com/chromium/src/+/refs/heads/main/base/files/file_util_posix.cc#1227) · [Linux unix(7)](https://man7.org/linux/man-pages/man7/unix.7.html)

## Отдельные предложения к ревью

- `verification-logs-short-path.patch` применяется к workflow 8bc65283 и задает короткий каталог только для native zoom. Сохраняет исходный код выхода и пропускает диагностические классы ошибок Chromium. Проверены разбор YAML, `bash -n`, тестовые строки фильтра и применимость diff.
- `native-zoom-assertions.patch` применяется к тестовому файлу точного кандидата. Прототип проверяет фактический `chrome.tabs.setZoom`, DPR и ширину 320 CSS px на 400%, обе темы, отсутствие переполнения, состояние фильтров и пагинации, порядок всех 50 строк и доступность их кнопок для фокуса. Сценарий также запускает axe A/AA. Тайм-ауты и полномочия не меняются. В репозиторий patch не внесен.
- При наличии допущенного runner сравнить исходный и короткий path с одним и тем же Chromium и синтетическим FastAPI, затем выполнить вариант с дополнительными утверждениями. Сохранить очищенную запись фазы отказа и агрегаты теста. Синтетический fixture со случайным паролем и временная SQLite не входят в доказательства.
